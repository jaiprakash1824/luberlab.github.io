// WhatWeDo.js
import "./ResHeader.css";

const ResHeader = () => {
  return (
    <div className="Researchheader">
      <div>
        <div className="Rhead">All Research</div>
      </div>
    </div>
  );
};

export default ResHeader;
